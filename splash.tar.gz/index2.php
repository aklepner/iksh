<!DOCTYPE html>
<html>
<head>

  <title>ikush.com</title>
  <link rel="stylesheet" href="splash/style.css">

</head>
<body class="maintenance-page" >


<?php
$error_message = '';
$error_class = 'ready';

if(isset($_POST['email'])) {

    // EDIT THE 2 LINES BELOW AS REQUIRED
 
    $email_to = "you@yourdomain.com";
 
    $email_subject = "ikush.com splash page newsletter subscription request";

     
    $email_from = $_POST['email']; // required
 

 
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
 
  if(!preg_match($email_exp,$email_from)) {
 
    $error_message .= 'The Email Address you entered does not appear to be valid.';
    $error_class = 'error';
  }


 
  if(strlen($error_message) > 0) {
 
    //died($error_message);
 
  }
 

    $email_message = "Form details below.\n\n";
 
     
 
    function clean_string($string) {
 
      $bad = array("content-type","bcc:","to:","cc:","href");
 
      return str_replace($bad,"",$string);
 
    }

 
    $email_message .= "ikush.com landing page Newsletter subscription request from Email: ".clean_string($email_from)."\n";
 

     
     
 
	// create email headers
	 
	$headers = 'From: '.$email_from."\r\n".
	 
	'Reply-To: '.$email_from."\r\n" .
	 
	'X-Mailer: PHP/' . phpversion();
	 
	@mail($email_to, $email_subject, $email_message, $headers); 

 
} else {
 
?>

<?php } 


/***************************
Facebook:https://www.facebook.com/pages/iKush/756225697777093
Twitter:https://twitter.com/ikush_420
Google+:https://plus.google.com/u/0/b/103073249805837635829/103073249805837635829/about
Pinterest: https://www.pinterest.com/iKush_420/
Instagram:http://instagram.com/ikush_420
****************************/


?>



  <div id="page" class="container">
    <header id="header" class="clearfix" role="banner">
      <div id="social">
        <img src="splash/social.png"  usemap="#ikush" />
	<map name="ikush">
	  <area shape="circle" title="Google+" target="_blank" alt="Google+" href="https://plus.google.com/u/0/b/103073249805837635829/103073249805837635829/about" coords="173,14,14" />
	  <area shape="circle" title="Instagram" target="_blank" alt="Instagram" href="http://instagram.com/ikush_420" coords="134,15,14" />
	  <area shape="circle" title="Twitter" target="_blank" alt="Twitter" href="https://twitter.com/ikush_420" coords="93,14,14" />
	  <area shape="circle" title="Facebook" target="_blank" alt="Facebook" href="https://www.facebook.com/pages/iKush/756225697777093" coords="53,14,14" />
	  <area shape="circle" title="email" alt="email" href="mailto:admin@ikush.com" coords="13,13,14" />
	</map></body>
      </div>
      <div id="branding">
          <div id="message">
             <img src="splash/check-back.png" />
          </div>
          <div id="logo">
            <a href="/"><img src="splash/splash-logo.png" alt="ikush.com" /></a>

          </div>
      </div>
    </header>
    <section id="main-content" role="main">
      <div id="content">

        <h2 class="form-title">For More Info & Updates Subscribe to our Newsletter</h2>
        <form id="newsletter"   method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
           <input type="text" name="email" value="" class="<?php echo $error_class ;?>" placeholder="EMAIL ADDRESS">
           <span class="<?php echo $error_class ;?>">* <?php echo $error_message;?></span>
           <input type="submit" name="submit" value="Submit"> 
        </form>
      </div>
    </section>
  </div>
</body>
</html>

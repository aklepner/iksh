Overview
========

Use the Browscap module to detect the user's device. Based on that information, redirect the user to the appropriate device group.

Installation
===========

- [Apply this patch](http://drupal.org/node/1713570) to "Browscap"
- Install Browscap or run update.php to apply the data change

Optional
--------

- Enable the [Chosen module](http://drupal.org/project/chosen)
- Apply the following patch
    - [Add hook_library support](http://drupal.org/node/1713584)

Usage
=====

TODO

Notes
=====

TODO

External Links
==============

TODO